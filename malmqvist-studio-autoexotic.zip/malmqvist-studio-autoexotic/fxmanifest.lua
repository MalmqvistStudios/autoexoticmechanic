fx_version 'cerulean'
game 'gta5'
lua54 "yes"

author 'Malmqvist Studios'
description 'Autoexotic Mechanic'
version '1.0.0'

this_is_a_map 'yes'

files {
  'gta5.meta',
  'doortunning.ymt'      
}

escrow_ignore {
  'stream/*.ytd',    
}

